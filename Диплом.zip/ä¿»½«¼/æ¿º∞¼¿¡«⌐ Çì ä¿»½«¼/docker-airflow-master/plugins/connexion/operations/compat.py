"""
This is a dummy module for backwards compatibility with < v2.0.
"""
from .secure import *  # noqa
from .swagger2 import *  # noqa
