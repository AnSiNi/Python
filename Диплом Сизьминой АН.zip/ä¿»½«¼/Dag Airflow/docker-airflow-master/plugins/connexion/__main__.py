"""
This module provides an entrypoint for Connexion's CLI.
"""

from connexion.cli import main  # pragma: no cover

main()  # pragma: no cover
