"""

"""
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
#from hooks.base import BaseHook
import pandas 
import requests
#from clickhouse_driver import Client
#from airflow.hooks.clickhouse_hook import ClickHouseHook
#from airflow.providers.postgres.hooks.postgres import PostgresHook
#from click_connection import ClickHouseConnection

#def taskcl(query):
#    ch_connection = ClickHouseConnection.get_connection()


def click_data(query,host,timeout=60,colums=None):
    r=requests.post(host,params={},timeout=timeout,data=query)
    if r.status_code==200:
        return r.text
    else:
        return -1




#def bar(conn_id, query):
#    hook = PostgresHook(postgres_conn_id=conn_id)
#    cnt=hook.get_first(query)
#    if isinstance(cnt,Tuple):
#        cnt=cnt[0]
#        return cnt
#    else:
#        return -1

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2015, 6, 1),
    "email": ["airflow@airflow.com"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "provider_context": True
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG("tutorial", default_args=default_args, schedule_interval=timedelta(1))

cl = PythonOperator(
     task_id="sql_q",
#     python_callable=bar,
     python_callable=click_data,
     op_kwargs={"host":"http://130.211.211.222:8123",
                "query":"SELECT count() from datasets.metrika"},
     dag=dag
)



cl
